﻿var utf8BOM = '☃';
