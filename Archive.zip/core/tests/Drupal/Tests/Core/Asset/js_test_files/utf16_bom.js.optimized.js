var utf8BOM = '☃';
